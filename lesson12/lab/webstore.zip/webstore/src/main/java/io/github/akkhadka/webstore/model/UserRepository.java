package io.github.akkhadka.webstore.model;

public interface UserRepository extends Repository<User,String> {
}
