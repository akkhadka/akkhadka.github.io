package io.github.akkhadka.webstore.service;

import io.github.akkhadka.webstore.model.Product;

import java.util.List;

public interface ProductService {
    List<Product> getProducts();
}
